<?php
    $rank_check = mysqli_query($con,"select user_rank from users where user_id='$userid'");
    $myrank = mysqli_fetch_array($rank_check);
    $user_rank = $myrank['user_rank'];

    $rank_checks = mysqli_query($con,"select user_status from users where user_id='$userid'");
    $mystatus = mysqli_fetch_array($rank_checks);
    $user_status = $mystatus['user_status'];
?>
<!-- Left Sidebar start-->

<div class="side-menu-fixed">
    <div class="scrollbar side-menu-bg">
        <ul class="nav navbar-nav side-menu" id="sidebarnav">
            <!-- menu item Dashboard-->
            <li>
                <span class="right-nav-text">
                    <div align="center">
                        <img src="https://img.sikatpinoy.net/images/2024/08/07/image-removebg-preview-2.png"
                            height="120" width="120">
                        <p style="color:white">ST.JOSEPH CATHEDRAL PARISH
                        </p>
                    </div>

                </span>
            </li>
            <li>
                <a href="dashboard">
                    <img src="https://img.sikatpinoy.net/images/2024/07/25/image.png" alt="Dashboard Image" height="20"
                        width="20"> Dashboard
                </a>
            </li>
            <?php if($user_rank == 'superadmin' ){ ?>

           
<li>
    <a href="javascript:void(0);" data-toggle="collapse" data-target="#Reservation"><img
            src="https://img.sikatpinoy.net/images/2024/07/26/image18cba3e3c0f81e30.png"
            alt="Dashboard Image" height="25" width="25">
            Manage Reservation<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Reservation" class="collapse">
    <a href="javascript:void(0);" data-toggle="collapse" data-target="#baptismal"><img
            src="https://img.sikatpinoy.net/images/2024/08/07/image-removebg-preview-1.png"
            alt="Dashboard Image" height="25" width="25">
            Baptismal<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="baptismal" class="collapse">
        <li> <a href="baptismal"> NEW 
        </a></li>
        <li> <a href="abaptismal"> APPROVED 
        </a></li>
        <li> <a href="dbaptismal"> DECLINED  
        </a></li>
        <li> <a href="cbaptismal"> CANCEL  
        </a></li>
        </ul>

        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Reconciliation"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/imageb8e9e5fbeba2e75b.png"
            alt="Dashboard Image" height="25" width="25">
            Reconciliation<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Reconciliation" class="collapse">
        <li> <a href="baptismal"> Reconciliation
        </a></li>
        </ul>


        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Confirmation"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/image48efe10dd8815c06.png"
            alt="Dashboard Image" height="25" width="25">
            Confirmation<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Confirmation" class="collapse">
        <li> <a href="baptismal"> Confirmation
        </a></li>
        </ul>


        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Anointing"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/image677f6437e1b32d77.png"
            alt="Dashboard Image" height="25" width="25">
            Anointing 
of Sick<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Anointing" class="collapse">
        <li> <a href="baptismal"> Anointing
        </a></li>
        </ul>


        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Funeral"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/image48efe10dd8815c06.png"
            alt="Dashboard Image" height="25" width="25">
            Funeral Mass <div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Funeral" class="collapse">
        <li> <a href="baptismal"> Anointing
        </a></li>
        </ul>

        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Wedding"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/imageebd8db62f2da2051.png"
            alt="Dashboard Image" height="25" width="25">
            Wedding<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Wedding" class="collapse">
        <li> <a href="baptismal"> Wedding
        </a></li>
        </ul>

        <a href="javascript:void(0);" data-toggle="collapse" data-target="#Car"><img
            src="https://img.sikatpinoy.net/images/2024/08/14/image031cce57a8506248.png"
            alt="Dashboard Image" height="25" width="25">
            Car/House
            Blessing<div class="pull-right"><i class="ti-plus"></i></div>
        <div class="clearfix"></div>
    </a>
    <ul id="Car" class="collapse">
        <li> <a href="baptismal"> Car
        </a></li>
        </ul>
 
    </ul>

    
<li>
    <a href="inquiries">
        <img src="https://img.sikatpinoy.net/images/2024/08/03/image0de202e879913da9.png"
            alt="Dashboard Image" height="20" width="20"> Manage inquiries
    </a>
</li>
<li>
    <a href="event">
        <img src="https://img.sikatpinoy.net/images/2024/08/03/image09dce3a988e61a91.png"
            alt="Dashboard Image" height="20" width="20"
            style="filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(100%) contrast(100%);">
        Manage Event Details
    </a>
</li>
<li>
    <a href="mass">
        <img src="https://img.sikatpinoy.net/images/2024/08/03/image09dce3a988e61a91.png"
            alt="Dashboard Image" height="20" width="20"
            style="filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(100%) contrast(100%);">
        Manage Mass Schedule
    </a>
</li>

<li>
    <a href="mass">
        <img src="https://img.sikatpinoy.net/images/2024/08/03/image09dce3a988e61a91.png"
            alt="Dashboard Image" height="20" width="20"
            style="filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(100%) contrast(100%);">
        Manage Form for Services
    </a>
</li>
<li>
    <a href="mails">

        Mailbox @ SMS Notification
    </a>
</li> 
</li>

<br><br><br><br><br>
<?php } ?>  
            <?php if($user_rank == 'normal' ){ ?>

           
            <li>
                <a href="javascript:void(0);" data-toggle="collapse" data-target="#Reservation"><img
                        src="https://img.sikatpinoy.net/images/2024/07/26/image18cba3e3c0f81e30.png"
                        alt="Dashboard Image" height="25" width="25">
                        Manage Reservation<div class="pull-right"><i class="ti-plus"></i></div>
                    <div class="clearfix"></div>
                </a>
                <ul id="Reservation" class="collapse">
                    <li>
                        <a href="baptismal">
                            <img src="https://img.sikatpinoy.net/images/2024/08/07/image-removebg-preview-1.png"
                                alt="Dashboard Image" height="20" width="25"
                                >
                            Baptismal
                        </a>
                    </li>
                    <li>
                        <a href="Reconciliation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/imageb8e9e5fbeba2e75b.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Reconciliation
                        </a>
                    </li>
                    <li>
                        <a href="Confirmation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/image48efe10dd8815c06.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Confirmation
                        </a>
                    </li>
                    <li>
                        <a href="Confirmation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/image677f6437e1b32d77.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Anointing 
of Sick
                        </a>
                    </li>
                    <li>
                        <a href="Confirmation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/image48efe10dd8815c06.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Funeral
Mass 
                        </a>
                    </li>
                    <li>
                        <a href="Confirmation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/imageebd8db62f2da2051.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Wedding
                        </a>
                    </li>
                    <li>
                        <a href="Confirmation">
                            <img src="https://img.sikatpinoy.net/images/2024/08/14/image031cce57a8506248.png"
                                alt="Dashboard Image" height="20" width="20"
                                >
                                Car/House
Blessing
                        </a>
                    </li>
                  
                </ul>
            </li>




            <!-- <li>
                <a href="bhw"> <img src="https://img.sikatpinoy.net/images/2024/07/27/image.png" alt="Dashboard Image"
                        height="20" width="20"><span class="right-nav-text"> All BHW </span>
                    <?php
// Define the desired is_active status (e.g., 1 for another specific user status)
$is_active_status = 0;

// Query to count users with the specified is_active status and normal rank
$total_users_query = mysqli_query($con, "SELECT COUNT(*) AS total_users FROM users WHERE is_active = $is_active_status AND user_rank='normal'");

// Check if query was successful
if ($total_users_query) {
    // Fetch the total count
    $row = mysqli_fetch_assoc($total_users_query);
    $total_users_count = $row['total_users'];

    // Display the total count
    echo '<span class="badge badge-danger">' . $total_users_count . '</span>';
}
?>

                </a>
            </li> -->

            <br> <br> <br> <br> <br> <br> <br><br><br><br>

            <?php } ?>

            <?php if($user_rank == 'normal' ){ ?>
            <!-- <li>
                <a href="chat1"> <img src="https://img.sikatpinoy.net/images/2024/07/30/11590282.png"
                        alt="Dashboard Image" height="25" width="25"
                        style="filter: invert(100%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(100%) contrast(100%);"><span
                        class="right-nav-text"> Chat Now</span></a>
            </li> -->

            <?php } ?>

            <!-- <li>
                <a href="change_password"><i class="ti-user"></i><span class="right-nav-text">Change Password</span></a>
            </li>

            <li>
                <a href="logout"><i class="text-danger ti-unlock"></i><span class="right-nav-text">LOGOUT</span></a>
            </li> -->
            <?php if($user_rank == 'normal' ){ ?>

            <br> <br> <br> <br> <br> <br> <br><br><br><br>
            <?php } ?>

        </ul>


    </div>

</div>

<!-- Left Sidebar End-->
